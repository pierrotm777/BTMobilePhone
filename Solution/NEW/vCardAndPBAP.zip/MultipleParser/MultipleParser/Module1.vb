﻿Imports MultipleParser.LumiSoft.Net.Mime.vCard
Imports System.Data.SQLite
Module Module1

    Public Sub Main()

        Dim cs As String = "URI=file:C:\Users\William\Desktop\Development\MultipleParser\phonebook.s3db"

        Dim itm As List(Of vCard) = vCard.ParseMultiple("c:\pb.vcf")
        For Each eyetm In itm
            Using con As New SQLiteConnection(cs)
                Dim SQLCommand As SQLiteCommand
                con.Open()
                SQLCommand = con.CreateCommand
                If eyetm.FormattedName IsNot "" Then
                    SQLCommand.CommandText = "SELECT * FROM Contacts WHERE Name =""" & eyetm.FormattedName & """"
                    If SQLCommand.ExecuteScalar() Is Nothing Then
                        SQLCommand.CommandText = "INSERT INTO Contacts (Name) VALUES (""" & eyetm.FormattedName & """)"
                        SQLCommand.ExecuteNonQuery()
                    End If
                End If
                Dim phones As PhoneNumberCollection = eyetm.PhoneNumbers
                For Each phone As PhoneNumber In phones

                    Select Case phone.NumberType
                        Case PhoneNumberType_enum.Cellular
                            SQLCommand.CommandText = "UPDATE Contacts SET MobilePhone = '" & phone.Number & "' WHERE Name = """ & eyetm.FormattedName & """"
                            SQLCommand.ExecuteNonQuery()

                        Case PhoneNumberType_enum.Home
                            SQLCommand.CommandText = "UPDATE Contacts SET HomePhone = '" & phone.Number & "' WHERE Name = """ & eyetm.FormattedName & """"
                            SQLCommand.ExecuteNonQuery()

                        Case PhoneNumberType_enum.Work
                            SQLCommand.CommandText = "UPDATE Contacts SET Work = '" & phone.Number & "' WHERE Name = """ & eyetm.FormattedName & """"
                            SQLCommand.ExecuteNonQuery()

                        Case PhoneNumberType_enum.Preferred Or PhoneNumberType_enum.Cellular
                            SQLCommand.CommandText = "UPDATE Contacts SET MobilePhone = '" & phone.Number & "' WHERE Name = """ & eyetm.FormattedName & """"
                            SQLCommand.ExecuteNonQuery()

                        Case PhoneNumberType_enum.Preferred Or PhoneNumberType_enum.Home
                            SQLCommand.CommandText = "UPDATE Contacts SET HomePhone = '" & phone.Number & "' WHERE Name = """ & eyetm.FormattedName & """"
                            SQLCommand.ExecuteNonQuery()

                        Case PhoneNumberType_enum.Preferred Or PhoneNumberType_enum.Work
                            SQLCommand.CommandText = "UPDATE Contacts SET Work = '" & phone.Number & "' WHERE Name = """ & eyetm.FormattedName & """"
                            SQLCommand.ExecuteNonQuery()

                    End Select
                Next
                SQLCommand.Dispose()
                con.Close()
            End Using
        Next




        'Dim c As String = "URI=file:C:\Users\William\Desktop\Development\MultipleParser\phonebook.s3db"
        'Dim count As Integer = 200
        'Dim it As List(Of vCard) = vCard.ParseMultiple("c:\cch.vcf")
        'For Each tm In it.Take(count)
        '    Using conn As New SQLiteConnection(c)
        '        Dim SQLCommand As SQLiteCommand
        '        conn.Open()
        '        SQLCommand = conn.CreateCommand
        '        If tm.FormattedName Is "" Then
        '            SQLCommand.CommandText = "INSERT INTO CallHistory (Name,CallType,PhoneType,PhoneNumber,DateTime) VALUES (""Unknown"",""" & tm.CallType & """,""" & Nothing & """,""" & tm.CallHistoryNum & """, """ & tm.CallDateTime & """)"
        '            SQLCommand.ExecuteNonQuery()
        '        Else
        '            SQLCommand.CommandText = "INSERT INTO CallHistory (Name,CallType,PhoneType,PhoneNumber,DateTime) VALUES (""" & tm.FormattedName & """,""" & tm.CallType & """,""" & tm.PhoneType & """,""" & tm.CallHistoryNum & """, """ & tm.CallDateTime & """)"
        '            SQLCommand.ExecuteNonQuery()
        '        End If

        '        SQLCommand.CommandText = "INSERT INTO CallHistory () VALUES (""" & tm.FormattedName & """)"

        '        SQLCommand.Dispose()
        '        conn.Close()
        '    End Using

        'Next
    End Sub


End Module
